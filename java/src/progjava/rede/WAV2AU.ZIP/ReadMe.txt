  -=Wav2Au ReadMe File=-

  Wav2Au was originally written by Anthony Hursh <hursha@saturn.math.uaa.alaska.edu>,
  I made some changes to the original program so it supports more types of WAV files,
  and fixed some bugs.  

  Overview:
  Wav2Au is a utility to convert Microsoft WAVE Files (.wav) to
  to Sun Microsystems AU format (.au) supported by Java.
  AU is the only audio format supported by Java Applets at this time.�
  Program supports only WAV files in PCM format and will convert it to Mono AU file with
  Sample Rate 8000, "Mu-Law" encoding. To convert WAVs to PCM format you may use
  standard Windows Sound Recorder: Open the file, on save change it's format to PCM.

  Program requires "Microsoft Java Virtual Machine (JVM)" to be installed on your computer,
  You already have JVM if you have MS Internet Explorer 3.02 (or later) installed.
  If not you may get it from here:
  http://www.microsoft.com/ie/download/
  
  In case you already have IE 3.02 (or later) and still have some problems you may try following
  these steps:
	1. Restart Internet Explorer (very important).
	2. Using Internet Explorer, go to the Microsoft Download JVM page:
		http://www.microsoft.com/java/vm/vmdownload.htm
	3. Choose the latest JVM available.� 
	4. Wait while Internet Explorer displays "Installing Components..." in the status bar. �
	   The JVM can take quite a while to install if you have a slow connection. 
	5. Restart your machine, and launch Wav2Au converter. 

  	
  Original Copyright 1997, 1998 by Anthony Hursh <hursha@saturn.math.uaa.alaska.edu>  


  Improvements and bug fix by:
	Yuri Margolin, <yurik5@usa.net>	http://members.xoom.com/my_soft/


  This is FreeWare, but please if distributing keep this file with the program.


  [14 February 1999]